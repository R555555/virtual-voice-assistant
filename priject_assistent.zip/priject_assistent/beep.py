import winsound

frequency = 1500
duraretion = 1200

winsound.Beep(frequency, duraretion)
