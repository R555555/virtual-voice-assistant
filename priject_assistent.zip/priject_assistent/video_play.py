import cv2
videoName = "E:\Rahul assets\pyton assets\priject_assistent\mustang.mp4"

video = cv2.VideoCapture(videoName)
if video.isOpened():
    print('Video Succefully opened')
else:
    print('Something went wrong check if the video name and path is correct')

scaleLevel = 3 


windowName = 'Video Reproducer'
cv2.namedWindow(windowName)

while True:
    ret, frame = video.read() 
    if not ret: 
        print("Could not read the frame")
        cv2.destroyWindow(windowName)
        break

    reescaled_frame = frame
    for i in range(scaleLevel-4):
        reescaled_frame = cv2.pyrDown(reescaled_frame)

    cv2.imshow(windowName, reescaled_frame)

    waitKey = (cv2.waitKey(50))
    if waitKey == ord('q'):  
        print(" closing video and exiting ")
        cv2.destroyWindow(windowName)
        video.release()
        break
 