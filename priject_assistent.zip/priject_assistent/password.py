import random

charectors = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
# pass_leng = int(input("length of password : "))
pass_leng = 10

password = ""
for i in range(0, pass_leng):
    pass_char = random.choice(charectors)
    password = password+pass_char
print(password)

