from playsound import playsound

playsound('E:\\Rahul assets\\pyton assets\\priject_assistent\\sd2.mp3')
# playsound('E:\\Rahul assets\\pyton assets\\priject_assistent\\sd1.mp3')
playsound('E:\\Rahul assets\\pyton assets\\priject_assistent\\sd3.mp3')
