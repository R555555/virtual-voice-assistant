import os
from urllib.request import urlopen
# import win32com.client as wincl
# from bs4 import BeautifulSoup
from ecapture import ecapture as ec
from clint.textui import progress
# from twilio.rest import Client
import smtplib
from playsound import playsound
import speech_recognition as sr
import pyttsx3
import pyjokes
import webbrowser
import time
from tkinter import *
# from PIL import ImageTk, Image
import pymysql
# import tkinter as tk
from tkinter import ttk, messagebox


# assistent main module ----------------------------------------------------------------------


def voicecd():
    root = Tk()
    # root.maxsize(width=500,  height=600)
    # root.minsize(width=500,  height=600)
    root.title("Voice Assistent")
    root.geometry('400x500+500+150')
    root.configure(bg='#0d0d0d', border=3)
    root.resizable(False, False)

    from PIL import ImageTk, Image

   # main voice function

    def cmd():

        engine = pyttsx3.init('sapi5')
        voices = engine.getProperty('voices')

        engine.setProperty('voice', voices[0].id)

        def speak(audio):
            engine.say(audio)
            engine.runAndWait()

        def sptext():
            while True:
                reconizer = sr.Recognizer()
                with sr.Microphone() as source:
                    print("Listening...")
                    reconizer.adjust_for_ambient_noise(source)
                    audio = reconizer.listen(source)
                    try:
                        print("Recognizing...")
                        data = reconizer.recognize_google(audio)
                        print(data)
                        return data
                    except sr.UnknownValueError:
                        print("Not understanding")
        # sptext()

        def beep():
            # playsound('E:\\Rahul assets\\pyton assets\\priject_assistent\\sd2.mp3')
            playsound(
                'E:\\Rahul assets\\pyton assets\\priject_assistent\\sd3.mp3')

        def speechtx(x):
            engine = pyttsx3.init()
            voices = engine.getProperty('voices')
            engine.setProperty('voice', voices[1].id)
            rate = engine.getProperty('rate')
            engine.setProperty('rate', 130)
            engine.say(x)
            engine.runAndWait()

        def takeCommand():
            r = sr.Recognizer()

            with sr.Microphone() as source:

                print("Listening...")
                r.pause_threshold = 1
                audio = r.listen(source)

            try:
                print("Recognizing...")
                query = r.recognize_google(audio, language='hi-in')
                print(f"User said: {query}\n")

            except Exception as e:
                print(e)
                print("Unable to Recognize your voice.")
                return "None"

            return query

        def sendEmail(to, content):
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.ehlo()
            server.starttls()

            # Enable low security in gmail
            server.login('rahulmanjhi593@gmail.com', 'carriminati@#1')
            server.sendmail('manjhirahul186@gmail.com', to, content)
            server.close()

        # speechtx("namaste Rahul ")
        beep()
        # if __name__ == '__main__':

        if "jani" or "jaani" in sptext().lower():

            while True:
                beep()
                data1 = sptext().lower()

                if "your name" in data1:
                    name = "my name is yuvi cheems"
                    speechtx(name)

                elif "my name" in data1:
                    name = "you name is Rahul Manjhi"
                    speechtx(name)

                elif "my university" in data1:
                    name = "Indira Gandhi national Tribal University..... The University is known as highest seat of learning. Indira Gandhi national Tribal University is fast marching ahead to fulfill its objectives andmission."
                    speechtx(name)

                elif "good morning" in data1:
                    grt = "good morning  shubhh prabhhat aap ka din shubh ho "
                    speechtx(grt)

                elif "thank you" in data1:
                    grt = "whalcom"
                    speechtx(grt)

                elif 'how are you' in data1:
                    speak("I am fine, Thank you")
                    speak("How are you, Sir")

                elif 'fine' in data1 or "good" in data1:
                    speak("It's good to know that your fine")

                elif 'girlfriend' in data1 or "my girlfrind" in data1:
                    speak("nandani betu")

                elif "about you" in data1:
                    about = "i am Cheems is based on an image of a dog named Balltze, from Hong Kong; he was adopted at the age of one and was nine years old in 2020"
                    speechtx(about)

                elif "old are you" in data1:
                    age = "mai beeesh saal ka hu "
                    speechtx(age)

                elif "order food" in data1:
                    speechtx("here i found on the web")
                    webbrowser.open("https://www.zomato.com/")

                elif "github" in data1:
                    speechtx("here i found on the web")
                    webbrowser.open("https://github.com/R555555")

                # elif "mail" in data1:
                #     speechtx("here i found on the web")
                #     webbrowser.open(
                #         "https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox")

                # elif "time" in data1:
                #     time = datetime.datetime.now().strftime("%I%M%p")
                #     speechtx(time)

                elif 'website' in data1:
                    speechtx("here i found on the web")
                    webbrowser.open(
                        "https://onlin-food.herokuapp.com/index.php?#home")

                elif 'i g n t u website' in data1 or 'university website' in data1:
                    speechtx("here i found on the web")
                    webbrowser.open(
                        "http://www.igntu.ac.in/")

                elif 'youtube' in data1:
                    speechtx("here i found on the web")
                    webbrowser.open("https://www.youtube.com/")

                elif 'linkedin' in data1:
                    speechtx("here i found on the web")
                    webbrowser.open("https://www.linkedin.com/feed/")

                elif 'facebook' in data1:
                    speechtx("here i found on the web")
                    webbrowser.open("https://www.facebook.com/")

                elif 'joke' in data1:
                    joke_1 = pyjokes.get_joke(
                        language="en", category="neutral")
                    speechtx(joke_1)

                elif 'translator' in data1:
                    speechtx("opning translator")
                    import transletor

                elif 'mustang' in data1:
                    speechtx("playing mustang video")
                    import video_play

                elif 'tesla stock' in data1:
                    speechtx("opning tesla stock")
                    import tesla_stock
                    speechtx(tesla_stock.price)

                elif 'password' in data1:
                    import password
                    speechtx(password.password)

                elif 'play song' in data1:
                    playsound('E:\\Rahul assets\\Guddu\\babe.mp3')

                elif 'open chrome' in data1:
                    codePath = r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
                    os.startfile(codePath)

                elif 'open google' in data1:
                    speak("Here you go to Google\n")
                    webbrowser.open("google.com")

                elif 'resume' in data1:
                    codePath = r"C:\\Users\\skman\\Downloads\\Rahul.pdf"
                    os.startfile(codePath)

                elif 'open stackoverflow' in data1:
                    speak("Here you go to Stack Over flow.Happy coding")
                    webbrowser.open("stackoverflow.com")

                elif 'send a mail' in data1:
                    try:
                        speak("What should I say?")
                        content = takeCommand()
                        speak("whome should i send")
                        to = input()
                        sendEmail(to, content)
                        speak("Email has been sent !")
                    except Exception as e:
                        print(e)
                        speak("I am not able to send this email")

                elif "who i am" in data1:
                    speak("If you talk then definitely your human.")

                elif "why you come to world" in data1:
                    speak("Thanks to Rahul. further It's a secret")

                elif "who are you" in data1:
                    speak("I am your virtual assistant created by Rahul manjhi")

                elif 'exit' in data1:
                    speechtx("thankyou ")
                    break
                time.sleep(2)
        else:
            speechtx("thankyou ")

    # ac = "hello"
    # canvas = Canvas()
    # canvas.create_oval(15, 15, 120, 120,
    #                    outline="black", fill="#0098bc",
    #                    width=8)
    # canvas.pack(expand=5)
    # canvas.configure(bg='#0d0d0d', border='0')
    # canvas.place(x=170, y=160)

    heading = Label(root, text='Virtual Assistant', fg='#0098bc', bg='#0d0d0d',
                    font=('Microsoft Yahei UT Light', 23, 'bold'))
    heading.place(x=70, y=60)
    Button(root, width=39, pady=7, text='Call Assistent', bg='#0098bc',
           fg='white', border=0, cursor='hand2', command=cmd).place(x=60, y=408)

    # photo = PhotoImage(file='E:\\Rahul assets\\HTML assets\\svg\\icee.png')
    # Button(root, text='Click Me !', image=photo,
    #        fg="white", padx=2, pady=2).pack(x=2, y=140)

    root.mainloop

# --------------------------------------------------------------------------------------------


def sininpage():

    # Signin page------------------------------------------------------------------------------------
    window.destroy()

    windo = Tk()
    windo.title("Signin in Voice Assistent")
    windo.geometry('925x500+300+200')
    windo.configure(bg='#fff')
    windo.resizable(False, False)

    # database -------------------------------------------------------------------------------

    def signin():
        mydb = pymysql.connect(
            host="localhost", user="root", password="carriminati@#", database="voice")

        # if (mydb):
        #     print("suc..")

        cur = mydb.cursor()

        name = luser.get()
        password = lcode.get()

        # query = "select * from vuser;"
        # cur.execute(query)
        # for i in cur:
        #     print(i)

        cur.execute("select * from vuser where name=%s and password = %s", (
            name, password))
        row = cur.fetchone()

        if row == None:
            messagebox.showerror("Error", "Invalid User Name And Password")
        else:
            messagebox.showinfo("Success", "Successfully Login")
            windo.destroy()
            voicecd()

    # login ui --------------------------

    img = PhotoImage(file='E:\\Rahul assets\\HTML assets\\svg\\log.png')
    Label(windo, image=img, border=0, bg='white').place(x=160, y=130)

    frame = Frame(windo, width='350', height='390', bg='#fff')
    frame.place(x=460, y=50)

    heading = Label(frame, text='Sign In', fg='#57a1f8', bg='white',
                    font=('Microsoft Yahei UT Light', 23, 'bold'))
    heading.place(x=100, y=5)

    # ----------------------------------------------------------------------------------------------

    luser = StringVar()
    lcod = StringVar()

    def lon_enter(e):
        luser.delete(0, 'end')

    def lon_leave(e):
        if luser.get() == '':
            luser.insert(0, 'username')

    luser = Entry(frame, width=25, fg='black', border=0,
                  bg='white', font=('Microsoft Yahei UT Light', 11))
    luser.place(x=30, y=80)
    luser.insert(0, ' Username')
    luser.bind("<FocusIn>", lon_enter)

    luser.bind("<FocusOut>", lon_leave)

    Frame(frame, width=295, height=2, background='black').place(x=25, y=107)

    # ----------------------------------------------------------------------------------------------

    def lon_enter(e):
        lcode.delete(0, 'end')

    def lon_leave(e):
        if lcode.get() == '':
            lcode.insert(0, 'password')

    lcode = Entry(frame, width=25, fg='black', border=0,
                  bg='white', font=('Microsoft Yahei UT Light', 11))
    lcode.place(x=30, y=150)
    lcode.insert(0, ' password')
    lcode.bind("<FocusIn>", lon_enter)
    lcode.bind("<FocusOut>", lon_leave)

    Frame(frame, width=295, height=2, background='black').place(x=25, y=177)

    # -----------------------------------------------------------------------------------

    Button(frame, width=39, pady=7, text='Signin', bg='#57a1f8',
           fg='white', border=0, cursor='hand2', command=signin).place(x=35, y=215)

    label = Label(frame, text='create account ', fg='black',
                  bg='white', font=('Microsoft Yahei UT Light', 9))
    label.place(x=90, y=300)

    signin = Button(frame, width=6, text='Signup', border=0,
                    bg='white', cursor='hand2', fg='#57a1f8')
    signin.place(x=200, y=300)

    windo.mainloop()


# Signup page -----------------------------------------------------------------------------------------------
window = Tk()
window.title("Signup in Voice Assistent")
window.geometry('925x500+300+200')
window.configure(bg='#fff')
window.resizable(False, False)

# database -------------------------------------------------------------------------------


def signup():
    mydb = pymysql.connect(host="localhost", user="root",
                           password="carriminati@#", database="voice")

    if (mydb):
        print("suc..")

    cur = mydb.cursor()

    # # creating database
    # cur.execute("CREATE DATABASE voice")

    # creating table
    # user = """CREATE TABLE vuser (
    #                    name  VARCHAR(20) NOT NULL,
    #                    password VARCHAR(20),
    #                    coform_password VARCHAR(20)
    #                    )"""

    # # table created
    # cur.execute(user)

    # insert data

    name = user.get()
    password = code.get()
    conform_password = conform_code.get()

    # print(name, password, conform_password)

    sql = "DELETE FROM vuser WHERE name = 'rahul'"
    cur.execute(sql)

    query = "insert into vuser(name, password, coform_password) values(%s, %s, %s)"
    cur.execute(query, (name, password, conform_password))
    mydb.commit()

    if (cur):
        voicecd()
        window.destroy()
        print("row : ", cur.rowcount)

    query = "select * from vuser;"
    cur.execute(query)
    for i in cur:
        print(i)

    # sql = "DELETE FROM vuser WHERE name = 'priya'"
    # cur.execute(sql)


img = PhotoImage(file='E:\\Rahul assets\\HTML assets\\svg\\be.png')
Label(window, image=img, border=0, bg='white').place(x=70, y=90)

frame = Frame(window, width='350', height='390', bg='#fff')
frame.place(x=460, y=50)

heading = Label(frame, text='Sign Up', fg='#57a1f8', bg='white',
                font=('Microsoft Yahei UT Light', 23, 'bold'))
heading.place(x=100, y=5)

# ----------------------------------------------------------------------------------------------

user = StringVar()
cod = StringVar()
conform_code = StringVar()


def on_enter(e):
    user.delete(0, 'end')


def on_leave(e):
    if user.get() == '':
        user.insert(0, 'username')


user = Entry(frame, width=25, fg='black', border=0,
             bg='white', font=('Microsoft Yahei UT Light', 11))
user.place(x=30, y=80)
user.insert(0, ' Username')
user.bind("<FocusIn>", on_enter)

user.bind("<FocusOut>", on_leave)

Frame(frame, width=295, height=2, background='black').place(x=25, y=107)

# ----------------------------------------------------------------------------------------------


def on_enter(e):
    code.delete(0, 'end')


def on_leave(e):
    if code.get() == '':
        code.insert(0, 'password')


code = Entry(frame, width=25, fg='black', border=0,
             bg='white', font=('Microsoft Yahei UT Light', 11))
code.place(x=30, y=150)
code.insert(0, ' password')
code.bind("<FocusIn>", on_enter)
code.bind("<FocusOut>", on_leave)

Frame(frame, width=295, height=2, background='black').place(x=25, y=177)

# ----------------------------------------------------------------------------------------------


def on_enter(e):
    conform_code.delete(0, 'end')


def on_leave(e):
    if conform_code.get() == '':
        conform_code.insert(0, 'conform password')


conform_code = Entry(frame, width=25, fg='black', border=0,
                     bg='white', font=('Microsoft Yahei UT Light', 11))
conform_code.place(x=30, y=220)
conform_code.insert(0, ' conform password')
conform_code.bind("<FocusIn>", on_enter)
conform_code.bind("<FocusOut>", on_leave)

Frame(frame, width=295, height=2, background='black').place(x=25, y=247)

# -----------------------------------------------------------------------------------

Button(frame, width=39, pady=7, text='SignUp', bg='#57a1f8',
       fg='white', border=0, cursor='hand2', command=signup).place(x=35, y=280)
label = Label(frame, text='I have an account ', fg='black',
              bg='white', font=('Microsoft Yahei UT Light', 9))
label.place(x=90, y=340)

signin = Button(frame, width=6, text='Signin', border=0,
                bg='white', cursor='hand2', fg='#57a1f8', command=sininpage)
signin.place(x=200, y=340)


window.mainloop()
# window.destroy()

# -------------------------------------------------------------------------------------------
