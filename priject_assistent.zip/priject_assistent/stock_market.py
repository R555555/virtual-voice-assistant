import datetime
import time
from plyer import notification

notification.notify(
    title="To-Do List".format(datetime.date.today()),
    message="1. project worck\n2. extra study\n3. play game",
    app_icon="E:/Rahul assets/pyton assets/priject_assistent/icon.png",
    timeout=10
)
